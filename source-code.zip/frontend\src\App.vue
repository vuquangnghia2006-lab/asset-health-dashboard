<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue'
import { useRoute } from 'vue-router'
import { exportStore } from './exportStore'

const route = useRoute()
const mainEl = ref(null)
const menuOpen = ref(false)

const nav = [
  { path: '/', label: 'Asset Overview' },
  { path: '/transformer-fleet', label: 'Transformer Fleet' },
  { path: '/data-quality', label: 'Asset Data Quality' },
]

const isActive = (p) => (p === '/' ? route.path === '/' : route.path.startsWith(p))

function toggleMenu() {
  menuOpen.value = !menuOpen.value
}

function onDocClick() {
  menuOpen.value = false
}

async function handleExport(fmt) {
  menuOpen.value = false
  const handler = exportStore.handlers[route.name]
  if (!handler) {
    alert('Chưa có dữ liệu để export. Hãy đợi dữ liệu tải xong.')
    return
  }
  try {
    await handler(fmt, mainEl.value)
  } catch (e) {
    alert('Export thất bại: ' + (e.message || e))
  }
}

onMounted(() => document.addEventListener('click', onDocClick))
onBeforeUnmount(() => document.removeEventListener('click', onDocClick))
</script>

<template>
  <header class="topbar">
    <div class="brand">
      <div class="logo">AH</div>
      <div>
        <div class="brand-title">Asset Health Management</div>
        <div class="brand-sub">Electric power asset status report</div>
      </div>
    </div>
    <div class="top-actions">
      <div class="export-menu">
        <button class="btn secondary" @click.stop="toggleMenu">Export ▾</button>
        <div v-if="menuOpen" class="export-dropdown" @click.stop>
          <button @click="handleExport('pdf')">Export PDF</button>
          <button @click="handleExport('xlsx')">Export Excel (.xlsx)</button>
          <button @click="handleExport('csv')">Export CSV</button>
        </div>
      </div>
    </div>
  </header>

  <div class="shell">
    <aside class="sidebar">
      <div class="nav-label">Dashboards</div>
      <router-link
        v-for="item in nav"
        :key="item.path"
        :to="item.path"
        class="nav-item"
        :class="{ active: isActive(item.path) }"
      >
        {{ item.label }}
      </router-link>
    </aside>

    <main ref="mainEl" class="main">
      <router-view />
    </main>
  </div>
</template>

<style scoped>
.nav-item {
  text-decoration: none;
  display: flex;
  align-items: center;
  gap: 9px;
}
</style>
